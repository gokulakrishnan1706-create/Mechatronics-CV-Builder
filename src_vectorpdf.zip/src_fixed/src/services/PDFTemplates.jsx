/**
 * PDFTemplates.jsx
 * True vector PDF generation using @react-pdf/renderer
 * — Fully selectable text (ATS-friendly)
 * — Perfect page breaks
 * — 3 templates: Classic, Modern, Executive
 */

import React from 'react';
import {
    Document, Page, Text, View, StyleSheet, Link, Font, pdf
} from '@react-pdf/renderer';

// ─── Register fonts (using built-in PDF fonts for reliability) ───
// Helvetica = Modern/Executive, Times-Roman = Classic

const stripHtml = (str) => (str || '').replace(/<[^>]*>/g, '');

// ═══════════════════════════════════════════════════════════════
// TEMPLATE 1: CLASSIC — Harvard serif style
// ═══════════════════════════════════════════════════════════════
const classicStyles = StyleSheet.create({
    page: { fontFamily: 'Times-Roman', fontSize: 10, lineHeight: 1.4, paddingTop: 45, paddingBottom: 45, paddingHorizontal: 54, color: '#0f172a', backgroundColor: '#ffffff' },
    name: { fontFamily: 'Times-Bold', fontSize: 22, textAlign: 'center', textTransform: 'uppercase', letterSpacing: 0.8, marginBottom: 5 },
    contactRow: { flexDirection: 'row', justifyContent: 'center', flexWrap: 'wrap', fontSize: 9, color: '#334155', marginBottom: 10 },
    contactText: { fontSize: 9, color: '#334155' },
    contactSep: { fontSize: 9, color: '#94a3b8', marginHorizontal: 6 },
    headerRule: { borderBottomWidth: 2, borderBottomColor: '#000000', marginBottom: 12 },
    profileText: { fontSize: 9.5, lineHeight: 1.5, color: '#1e293b', textAlign: 'justify', marginBottom: 14 },
    sectionHeader: { fontFamily: 'Times-Bold', fontSize: 10, textTransform: 'uppercase', letterSpacing: 2, borderBottomWidth: 1, borderBottomColor: '#000', paddingBottom: 2, marginBottom: 7, marginTop: 4 },
    jobBlock: { marginBottom: 10 },
    jobRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 1 },
    jobCompany: { fontFamily: 'Times-Bold', fontSize: 10 },
    jobPeriod: { fontSize: 9, color: '#334155' },
    jobRole: { fontFamily: 'Times-Italic', fontSize: 9.5, color: '#334155', marginBottom: 3 },
    jobContext: { fontSize: 9, color: '#475569', lineHeight: 1.45, marginBottom: 3, textAlign: 'justify' },
    bullet: { flexDirection: 'row', marginBottom: 2, paddingLeft: 12 },
    bulletDot: { width: 12, fontSize: 9.5, color: '#1e293b' },
    bulletText: { flex: 1, fontSize: 9.5, lineHeight: 1.45, color: '#1e293b', textAlign: 'justify' },
    eduBlock: { marginBottom: 8 },
    skillsGrid: { flexDirection: 'row', flexWrap: 'wrap', marginBottom: 4 },
    skillsLabel: { fontFamily: 'Times-Bold', fontSize: 9, textTransform: 'uppercase', letterSpacing: 0.4, width: '35%', paddingRight: 8 },
    skillsValue: { fontSize: 9.5, color: '#1e293b', width: '65%' },
    skillsRow: { flexDirection: 'row', marginBottom: 3 },
    ecRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 1 },
    ecRole: { fontFamily: 'Times-Bold', fontSize: 9.5 },
    ecOrg: { fontFamily: 'Times-Italic', fontSize: 9.5, color: '#334155' },
    ecPeriod: { fontSize: 9, color: '#334155' },
});

export const ClassicPDF = ({ resumeData }) => {
    const { personal, personal_profile, education, professional_qualifications, work_experience, extra_curricular } = resumeData;
    const contacts = [
        personal?.email, personal?.phone, personal?.location, personal?.linkedin ? 'LinkedIn' : null
    ].filter(Boolean);

    return (
        <Document title={`${personal?.name || 'CV'} - Classic`} author={personal?.name}>
            <Page size="A4" style={classicStyles.page}>
                {/* Header */}
                <Text style={classicStyles.name}>{personal?.name || ''}</Text>
                <View style={classicStyles.contactRow}>
                    {contacts.map((c, i) => (
                        <React.Fragment key={i}>
                            <Text style={classicStyles.contactText}>{c}</Text>
                            {i < contacts.length - 1 && <Text style={classicStyles.contactSep}>|</Text>}
                        </React.Fragment>
                    ))}
                </View>
                <View style={classicStyles.headerRule} />

                {/* Profile */}
                {personal_profile && <Text style={classicStyles.profileText}>{personal_profile}</Text>}

                {/* Experience */}
                {work_experience?.length > 0 && (
                    <View>
                        <Text style={classicStyles.sectionHeader}>Experience</Text>
                        {work_experience.map((job, i) => (
                            <View key={i} style={classicStyles.jobBlock} wrap={false}>
                                <View style={classicStyles.jobRow}>
                                    <Text style={classicStyles.jobCompany}>{job.company}</Text>
                                    <Text style={classicStyles.jobPeriod}>{job.period}</Text>
                                </View>
                                <Text style={classicStyles.jobRole}>{job.role}</Text>
                                {job.context && <Text style={classicStyles.jobContext}>{job.context}</Text>}
                                {job.achievements?.filter(a => a.trim()).map((a, ai) => (
                                    <View key={ai} style={classicStyles.bullet}>
                                        <Text style={classicStyles.bulletDot}>•</Text>
                                        <Text style={classicStyles.bulletText}>{a}</Text>
                                    </View>
                                ))}
                            </View>
                        ))}
                    </View>
                )}

                {/* Education */}
                {education?.length > 0 && (
                    <View>
                        <Text style={classicStyles.sectionHeader}>Education</Text>
                        {education.map((edu, i) => (
                            <View key={i} style={classicStyles.eduBlock} wrap={false}>
                                <View style={classicStyles.jobRow}>
                                    <Text style={classicStyles.jobCompany}>{edu.institution}</Text>
                                    <Text style={classicStyles.jobPeriod}>{edu.period}</Text>
                                </View>
                                <Text style={classicStyles.jobRole}>{edu.degree}</Text>
                                {edu.bullets?.filter(b => b.trim()).map((b, bi) => (
                                    <View key={bi} style={classicStyles.bullet}>
                                        <Text style={classicStyles.bulletDot}>•</Text>
                                        <Text style={classicStyles.bulletText}>{stripHtml(b)}</Text>
                                    </View>
                                ))}
                            </View>
                        ))}
                    </View>
                )}

                {/* Technical Skills */}
                {professional_qualifications?.length > 0 && (
                    <View wrap={false}>
                        <Text style={classicStyles.sectionHeader}>Technical Expertise</Text>
                        {professional_qualifications.map((q, i) => (
                            <View key={i} style={classicStyles.skillsRow}>
                                <Text style={classicStyles.skillsLabel}>{q.category}</Text>
                                <Text style={classicStyles.skillsValue}>{q.skills}</Text>
                            </View>
                        ))}
                    </View>
                )}

                {/* Leadership */}
                {extra_curricular?.length > 0 && (
                    <View>
                        <Text style={classicStyles.sectionHeader}>Leadership & Initiatives</Text>
                        {extra_curricular.map((ec, i) => (
                            <View key={i} wrap={false} style={{ marginBottom: 8 }}>
                                <View style={classicStyles.ecRow}>
                                    <Text>
                                        <Text style={classicStyles.ecRole}>{ec.role}</Text>
                                        {ec.organization && <Text style={classicStyles.ecOrg}>, {ec.organization}</Text>}
                                    </Text>
                                    <Text style={classicStyles.ecPeriod}>{ec.period}</Text>
                                </View>
                                {ec.bullets?.filter(b => b.trim()).map((b, bi) => (
                                    <View key={bi} style={classicStyles.bullet}>
                                        <Text style={classicStyles.bulletDot}>•</Text>
                                        <Text style={classicStyles.bulletText}>{b}</Text>
                                    </View>
                                ))}
                            </View>
                        ))}
                    </View>
                )}
            </Page>
        </Document>
    );
};

// ═══════════════════════════════════════════════════════════════
// TEMPLATE 2: MODERN — Clean sans-serif, blue accents
// ═══════════════════════════════════════════════════════════════
const BLUE = '#2563EB';
const modernStyles = StyleSheet.create({
    page: { fontFamily: 'Helvetica', fontSize: 10, lineHeight: 1.5, paddingTop: 42, paddingBottom: 42, paddingHorizontal: 50, color: '#1e293b', backgroundColor: '#ffffff' },
    name: { fontFamily: 'Helvetica-Bold', fontSize: 24, color: '#0f172a', letterSpacing: -0.3, marginBottom: 4 },
    contactRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 12, fontSize: 8.5, color: '#64748b', marginBottom: 14 },
    contactItem: { fontSize: 8.5, color: '#64748b' },
    accentBar: { height: 3, backgroundColor: BLUE, marginBottom: 18, borderRadius: 2 },
    profileBox: { backgroundColor: '#f8fafc', borderLeftWidth: 3, borderLeftColor: BLUE, paddingVertical: 10, paddingHorizontal: 13, marginBottom: 18 },
    profileText: { fontSize: 9.5, lineHeight: 1.6, color: '#334155' },
    sectionHeaderRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 10, marginTop: 4 },
    sectionHeaderText: { fontFamily: 'Helvetica-Bold', fontSize: 10.5, textTransform: 'uppercase', letterSpacing: 1.5, color: '#0f172a' },
    sectionLine: { flex: 1, height: 1, backgroundColor: '#e2e8f0', marginLeft: 8 },
    jobBlock: { marginBottom: 14, paddingLeft: 10, borderLeftWidth: 2, borderLeftColor: '#e2e8f0' },
    jobTopRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 1 },
    jobRole: { fontFamily: 'Helvetica-Bold', fontSize: 10.5, color: '#0f172a' },
    jobCompany: { fontFamily: 'Helvetica-Bold', fontSize: 9, color: BLUE, marginBottom: 3 },
    jobBadge: { fontSize: 8, color: '#64748b', backgroundColor: '#f1f5f9', paddingVertical: 2, paddingHorizontal: 7, borderRadius: 99 },
    jobContext: { fontSize: 9, color: '#475569', lineHeight: 1.45, marginBottom: 3 },
    bullet: { flexDirection: 'row', marginBottom: 2.5, paddingLeft: 4 },
    bulletDot: { width: 12, fontSize: 9.5, color: '#334155' },
    bulletText: { flex: 1, fontSize: 9.5, lineHeight: 1.45, color: '#334155' },
    skillsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 6 },
    skillCard: { width: '47%', backgroundColor: '#f8fafc', borderWidth: 1, borderColor: '#e2e8f0', borderRadius: 5, paddingVertical: 7, paddingHorizontal: 10, marginBottom: 6 },
    skillCardLabel: { fontFamily: 'Helvetica-Bold', fontSize: 7.5, textTransform: 'uppercase', letterSpacing: 0.5, color: BLUE, marginBottom: 2 },
    skillCardValue: { fontSize: 8.5, color: '#475569', lineHeight: 1.4 },
    ecBlock: { marginBottom: 9, paddingLeft: 10, borderLeftWidth: 2, borderLeftColor: '#e2e8f0' },
    ecRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 2 },
    ecRole: { fontFamily: 'Helvetica-Bold', fontSize: 10, color: '#0f172a' },
    ecOrg: { fontSize: 9, color: '#64748b' },
    ecBadge: { fontSize: 8, color: '#64748b', backgroundColor: '#f1f5f9', paddingVertical: 2, paddingHorizontal: 7, borderRadius: 99 },
});

export const ModernPDF = ({ resumeData }) => {
    const { personal, personal_profile, education, professional_qualifications, work_experience, extra_curricular } = resumeData;

    return (
        <Document title={`${personal?.name || 'CV'} - Modern`} author={personal?.name}>
            <Page size="A4" style={modernStyles.page}>
                {/* Header */}
                <Text style={modernStyles.name}>{personal?.name || ''}</Text>
                <View style={modernStyles.contactRow}>
                    {personal?.email && <Text style={modernStyles.contactItem}>✉ {personal.email}</Text>}
                    {personal?.phone && <Text style={modernStyles.contactItem}>  {personal.phone}</Text>}
                    {personal?.location && <Text style={modernStyles.contactItem}>  {personal.location}</Text>}
                    {personal?.linkedin && <Text style={[modernStyles.contactItem, { color: BLUE }]}>  LinkedIn</Text>}
                </View>
                <View style={modernStyles.accentBar} />

                {/* Profile */}
                {personal_profile && (
                    <View style={modernStyles.profileBox}>
                        <Text style={modernStyles.profileText}>{personal_profile}</Text>
                    </View>
                )}

                {/* Experience */}
                {work_experience?.length > 0 && (
                    <View>
                        <View style={modernStyles.sectionHeaderRow}>
                            <Text style={modernStyles.sectionHeaderText}>Experience</Text>
                            <View style={modernStyles.sectionLine} />
                        </View>
                        {work_experience.map((job, i) => (
                            <View key={i} style={modernStyles.jobBlock} wrap={false}>
                                <View style={modernStyles.jobTopRow}>
                                    <View>
                                        <Text style={modernStyles.jobRole}>{job.role}</Text>
                                        <Text style={modernStyles.jobCompany}>{job.company}</Text>
                                    </View>
                                    <Text style={modernStyles.jobBadge}>{job.period}</Text>
                                </View>
                                {job.context && <Text style={modernStyles.jobContext}>{job.context}</Text>}
                                {job.achievements?.filter(a => a.trim()).map((a, ai) => (
                                    <View key={ai} style={modernStyles.bullet}>
                                        <Text style={modernStyles.bulletDot}>•</Text>
                                        <Text style={modernStyles.bulletText}>{a}</Text>
                                    </View>
                                ))}
                            </View>
                        ))}
                    </View>
                )}

                {/* Education */}
                {education?.length > 0 && (
                    <View>
                        <View style={modernStyles.sectionHeaderRow}>
                            <Text style={modernStyles.sectionHeaderText}>Education</Text>
                            <View style={modernStyles.sectionLine} />
                        </View>
                        {education.map((edu, i) => (
                            <View key={i} style={modernStyles.jobBlock} wrap={false}>
                                <View style={modernStyles.jobTopRow}>
                                    <View>
                                        <Text style={modernStyles.jobRole}>{edu.institution}</Text>
                                        <Text style={modernStyles.jobCompany}>{edu.degree}</Text>
                                    </View>
                                    <Text style={modernStyles.jobBadge}>{edu.period}</Text>
                                </View>
                                {edu.bullets?.filter(b => b.trim()).map((b, bi) => (
                                    <View key={bi} style={modernStyles.bullet}>
                                        <Text style={modernStyles.bulletDot}>•</Text>
                                        <Text style={modernStyles.bulletText}>{stripHtml(b)}</Text>
                                    </View>
                                ))}
                            </View>
                        ))}
                    </View>
                )}

                {/* Skills */}
                {professional_qualifications?.length > 0 && (
                    <View wrap={false}>
                        <View style={modernStyles.sectionHeaderRow}>
                            <Text style={modernStyles.sectionHeaderText}>Skills</Text>
                            <View style={modernStyles.sectionLine} />
                        </View>
                        <View style={modernStyles.skillsGrid}>
                            {professional_qualifications.map((q, i) => (
                                <View key={i} style={modernStyles.skillCard}>
                                    <Text style={modernStyles.skillCardLabel}>{q.category}</Text>
                                    <Text style={modernStyles.skillCardValue}>{q.skills}</Text>
                                </View>
                            ))}
                        </View>
                    </View>
                )}

                {/* Leadership */}
                {extra_curricular?.length > 0 && (
                    <View>
                        <View style={modernStyles.sectionHeaderRow}>
                            <Text style={modernStyles.sectionHeaderText}>Leadership</Text>
                            <View style={modernStyles.sectionLine} />
                        </View>
                        {extra_curricular.map((ec, i) => (
                            <View key={i} style={modernStyles.ecBlock} wrap={false}>
                                <View style={modernStyles.ecRow}>
                                    <Text>
                                        <Text style={modernStyles.ecRole}>{ec.role}</Text>
                                        {ec.organization && <Text style={modernStyles.ecOrg}> · {ec.organization}</Text>}
                                    </Text>
                                    <Text style={modernStyles.ecBadge}>{ec.period}</Text>
                                </View>
                                {ec.bullets?.filter(b => b.trim()).map((b, bi) => (
                                    <View key={bi} style={modernStyles.bullet}>
                                        <Text style={modernStyles.bulletDot}>•</Text>
                                        <Text style={modernStyles.bulletText}>{b}</Text>
                                    </View>
                                ))}
                            </View>
                        ))}
                    </View>
                )}
            </Page>
        </Document>
    );
};

// ═══════════════════════════════════════════════════════════════
// TEMPLATE 3: EXECUTIVE — Dark header, gold accents
// ═══════════════════════════════════════════════════════════════
const NAVY = '#0f172a';
const GOLD = '#f59e0b';
const execStyles = StyleSheet.create({
    page: { fontFamily: 'Times-Roman', fontSize: 10, lineHeight: 1.45, paddingBottom: 45, color: '#1a1a2e', backgroundColor: '#ffffff' },
    header: { backgroundColor: NAVY, paddingTop: 32, paddingBottom: 24, paddingHorizontal: 54 },
    name: { fontFamily: 'Times-Bold', fontSize: 24, color: '#ffffff', textTransform: 'uppercase', letterSpacing: 2, marginBottom: 6 },
    goldBar: { width: 44, height: 2.5, backgroundColor: GOLD, marginBottom: 10, borderRadius: 1 },
    contactRow: { flexDirection: 'row', flexWrap: 'wrap', fontSize: 8.5, color: '#94a3b8' },
    contactText: { fontSize: 8.5, color: '#94a3b8' },
    contactSep: { fontSize: 8.5, color: '#475569', marginHorizontal: 8 },
    accentStripe: { height: 4, backgroundColor: GOLD },
    body: { paddingHorizontal: 54, paddingTop: 24 },
    profileBox: { borderLeftWidth: 3, borderLeftColor: GOLD, paddingLeft: 13, marginBottom: 18 },
    profileText: { fontFamily: 'Times-Italic', fontSize: 9.5, lineHeight: 1.6, color: '#334155' },
    sectionHeaderWrap: { marginBottom: 9, marginTop: 4 },
    sectionHeaderText: { fontFamily: 'Times-Bold', fontSize: 10, textTransform: 'uppercase', letterSpacing: 2, color: NAVY, marginBottom: 3 },
    sectionLine: { height: 1, backgroundColor: GOLD },
    jobBlock: { marginBottom: 14 },
    jobHeaderBox: { backgroundColor: '#f8fafc', paddingVertical: 7, paddingHorizontal: 11, borderRadius: 3, marginBottom: 4, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' },
    jobCompany: { fontFamily: 'Times-Bold', fontSize: 10.5, color: NAVY },
    jobRole: { fontFamily: 'Times-Italic', fontSize: 9.5, color: GOLD },
    jobPeriod: { fontFamily: 'Times-Roman', fontSize: 8.5, color: '#64748b' },
    jobContext: { fontSize: 9, color: '#475569', lineHeight: 1.45, paddingLeft: 11, marginBottom: 3 },
    bullet: { flexDirection: 'row', marginBottom: 2.5, paddingLeft: 20 },
    bulletDot: { width: 12, fontSize: 9.5, color: '#334155' },
    bulletText: { flex: 1, fontSize: 9.5, lineHeight: 1.45, color: '#334155' },
    skillsRow: { flexDirection: 'row', marginBottom: 4, alignItems: 'flex-start' },
    skillsLabel: { fontFamily: 'Helvetica-Bold', fontSize: 8.5, textTransform: 'uppercase', letterSpacing: 0.5, color: NAVY, width: '38%', borderRightWidth: 1, borderRightColor: GOLD, paddingRight: 10, paddingTop: 1 },
    skillsValue: { fontSize: 9, color: '#334155', width: '62%', paddingLeft: 12, lineHeight: 1.4 },
    ecBlock: { marginBottom: 9 },
    ecRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 2 },
    ecRole: { fontFamily: 'Times-Bold', fontSize: 10 },
    ecOrg: { fontFamily: 'Times-Italic', fontSize: 9.5, color: '#64748b' },
    ecPeriod: { fontSize: 8.5, color: '#64748b' },
});

export const ExecutivePDF = ({ resumeData }) => {
    const { personal, personal_profile, education, professional_qualifications, work_experience, extra_curricular } = resumeData;
    const contacts = [
        personal?.email, personal?.phone, personal?.location, personal?.linkedin ? 'LinkedIn' : null
    ].filter(Boolean);

    return (
        <Document title={`${personal?.name || 'CV'} - Executive`} author={personal?.name}>
            <Page size="A4" style={execStyles.page}>
                {/* Dark Header */}
                <View style={execStyles.header} fixed={false}>
                    <Text style={execStyles.name}>{personal?.name || ''}</Text>
                    <View style={execStyles.goldBar} />
                    <View style={execStyles.contactRow}>
                        {contacts.map((c, i) => (
                            <React.Fragment key={i}>
                                <Text style={execStyles.contactText}>{c}</Text>
                                {i < contacts.length - 1 && <Text style={execStyles.contactSep}>·</Text>}
                            </React.Fragment>
                        ))}
                    </View>
                </View>
                {/* Gold stripe */}
                <View style={execStyles.accentStripe} />

                <View style={execStyles.body}>
                    {/* Profile */}
                    {personal_profile && (
                        <View style={execStyles.profileBox}>
                            <Text style={execStyles.profileText}>{personal_profile}</Text>
                        </View>
                    )}

                    {/* Experience */}
                    {work_experience?.length > 0 && (
                        <View>
                            <ExecSectionHeader>Professional Experience</ExecSectionHeader>
                            {work_experience.map((job, i) => (
                                <View key={i} style={execStyles.jobBlock} wrap={false}>
                                    <View style={execStyles.jobHeaderBox}>
                                        <View>
                                            <Text style={execStyles.jobCompany}>{job.company}</Text>
                                            <Text style={execStyles.jobRole}>{job.role}</Text>
                                        </View>
                                        <Text style={execStyles.jobPeriod}>{job.period}</Text>
                                    </View>
                                    {job.context && <Text style={execStyles.jobContext}>{job.context}</Text>}
                                    {job.achievements?.filter(a => a.trim()).map((a, ai) => (
                                        <View key={ai} style={execStyles.bullet}>
                                            <Text style={execStyles.bulletDot}>•</Text>
                                            <Text style={execStyles.bulletText}>{a}</Text>
                                        </View>
                                    ))}
                                </View>
                            ))}
                        </View>
                    )}

                    {/* Education */}
                    {education?.length > 0 && (
                        <View>
                            <ExecSectionHeader>Education</ExecSectionHeader>
                            {education.map((edu, i) => (
                                <View key={i} style={{ marginBottom: 10 }} wrap={false}>
                                    <View style={execStyles.jobHeaderBox}>
                                        <View>
                                            <Text style={execStyles.jobCompany}>{edu.institution}</Text>
                                            <Text style={execStyles.jobRole}>{edu.degree}</Text>
                                        </View>
                                        <Text style={execStyles.jobPeriod}>{edu.period}</Text>
                                    </View>
                                    {edu.bullets?.filter(b => b.trim()).map((b, bi) => (
                                        <View key={bi} style={execStyles.bullet}>
                                            <Text style={execStyles.bulletDot}>•</Text>
                                            <Text style={execStyles.bulletText}>{stripHtml(b)}</Text>
                                        </View>
                                    ))}
                                </View>
                            ))}
                        </View>
                    )}

                    {/* Core Competencies */}
                    {professional_qualifications?.length > 0 && (
                        <View wrap={false}>
                            <ExecSectionHeader>Core Competencies</ExecSectionHeader>
                            {professional_qualifications.map((q, i) => (
                                <View key={i} style={execStyles.skillsRow}>
                                    <Text style={execStyles.skillsLabel}>{q.category}</Text>
                                    <Text style={execStyles.skillsValue}>{q.skills}</Text>
                                </View>
                            ))}
                        </View>
                    )}

                    {/* Leadership */}
                    {extra_curricular?.length > 0 && (
                        <View>
                            <ExecSectionHeader>Leadership & Affiliations</ExecSectionHeader>
                            {extra_curricular.map((ec, i) => (
                                <View key={i} style={execStyles.ecBlock} wrap={false}>
                                    <View style={execStyles.ecRow}>
                                        <Text>
                                            <Text style={execStyles.ecRole}>{ec.role}</Text>
                                            {ec.organization && <Text style={execStyles.ecOrg}> — {ec.organization}</Text>}
                                        </Text>
                                        <Text style={execStyles.ecPeriod}>{ec.period}</Text>
                                    </View>
                                    {ec.bullets?.filter(b => b.trim()).map((b, bi) => (
                                        <View key={bi} style={execStyles.bullet}>
                                            <Text style={execStyles.bulletDot}>•</Text>
                                            <Text style={execStyles.bulletText}>{b}</Text>
                                        </View>
                                    ))}
                                </View>
                            ))}
                        </View>
                    )}
                </View>
            </Page>
        </Document>
    );
};

const ExecSectionHeader = ({ children }) => (
    <View style={execStyles.sectionHeaderWrap}>
        <Text style={execStyles.sectionHeaderText}>{children}</Text>
        <View style={execStyles.sectionLine} />
    </View>
);

// ═══════════════════════════════════════════════════════════════
// UNIFIED PDF GENERATOR — call this from BuilderWorkspace
// ═══════════════════════════════════════════════════════════════
export const generatePDF = async (resumeData, template = 'classic') => {
    const components = {
        classic: <ClassicPDF resumeData={resumeData} />,
        modern: <ModernPDF resumeData={resumeData} />,
        executive: <ExecutivePDF resumeData={resumeData} />,
    };

    const doc = components[template] || components.classic;
    const blob = await pdf(doc).toBlob();
    return blob;
};

// ═══════════════════════════════════════════════════════════════
// PART-TIME CV PDF — Warehouse / Care Home / Freelance
// ═══════════════════════════════════════════════════════════════
const SECTOR_COLORS = {
    warehouse: '#f59e0b',
    carehome:  '#ec4899',
    freelance: '#8b5cf6',
};

const ptStyles = StyleSheet.create({
    page: { fontFamily: 'Helvetica', fontSize: 10, lineHeight: 1.5, paddingTop: 0, paddingBottom: 40, color: '#1e293b', backgroundColor: '#ffffff' },
    headerBox: { paddingTop: 32, paddingBottom: 22, paddingHorizontal: 50 },
    name: { fontFamily: 'Helvetica-Bold', fontSize: 22, color: '#0f172a', marginBottom: 3 },
    sectorLabel: { fontSize: 8, fontFamily: 'Helvetica-Bold', textTransform: 'uppercase', letterSpacing: 1, marginBottom: 8 },
    contactRow: { flexDirection: 'row', flexWrap: 'wrap', fontSize: 8.5, color: '#64748b', gap: 10 },
    body: { paddingHorizontal: 50, paddingTop: 20 },
    statementBox: { borderLeftWidth: 3, paddingLeft: 12, paddingVertical: 8, marginBottom: 16, backgroundColor: '#fafafa' },
    statementText: { fontSize: 9.5, lineHeight: 1.6, color: '#334155' },
    twoCol: { flexDirection: 'row', gap: 18 },
    leftCol: { width: '35%' },
    rightCol: { width: '65%' },
    sectionLabel: { fontFamily: 'Helvetica-Bold', fontSize: 8, textTransform: 'uppercase', letterSpacing: 1.5, paddingBottom: 4, borderBottomWidth: 1.5, marginBottom: 8 },
    skillItem: { flexDirection: 'row', paddingVertical: 3, borderBottomWidth: 1, borderBottomColor: '#f1f5f9', fontSize: 9, alignItems: 'flex-start', gap: 5 },
    skillDot: { fontSize: 9, fontFamily: 'Helvetica-Bold' },
    skillText: { flex: 1, fontSize: 9, color: '#334155' },
    jobBlock: { marginBottom: 12, paddingBottom: 10, borderBottomWidth: 1, borderBottomColor: '#f1f5f9' },
    jobRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 2 },
    jobRole: { fontFamily: 'Helvetica-Bold', fontSize: 10 },
    jobBadge: { fontSize: 7.5, color: '#64748b', backgroundColor: '#f8fafc', paddingVertical: 2, paddingHorizontal: 6, borderRadius: 99, borderWidth: 1, borderColor: '#e2e8f0' },
    jobCompany: { fontFamily: 'Helvetica-Bold', fontSize: 8.5, marginBottom: 4 },
    bullet: { flexDirection: 'row', marginBottom: 2, paddingLeft: 8 },
    bulletDot: { width: 10, fontSize: 9 },
    bulletText: { flex: 1, fontSize: 9, lineHeight: 1.45, color: '#334155' },
    eduBlock: { marginBottom: 9 },
    eduInst: { fontFamily: 'Helvetica-Bold', fontSize: 9.5, color: '#0f172a' },
    eduDeg: { fontSize: 8.5, fontFamily: 'Helvetica-Oblique' },
    eduPeriod: { fontSize: 8, color: '#94a3b8', marginTop: 1 },
    footer: { marginTop: 20, paddingTop: 10, borderTopWidth: 1, borderTopColor: '#f1f5f9', fontSize: 8, color: '#94a3b8', textAlign: 'center' },
});

export const PartTimePDF = ({ data, sector = 'warehouse' }) => {
    const color = SECTOR_COLORS[sector] || '#2563EB';
    const sectorLabel = { warehouse: 'Warehouse & Logistics', carehome: 'Care Home & Support Work', freelance: 'Freelance & Gig Work' }[sector];
    const { personal, objective, skills, work_experience, education } = data;

    return (
        <Document title={`${personal?.name || 'CV'} - Part Time`} author={personal?.name}>
            <Page size="A4" style={ptStyles.page}>
                {/* Coloured Header */}
                <View style={[ptStyles.headerBox, { borderBottomWidth: 3, borderBottomColor: color }]}>
                    <Text style={ptStyles.name}>{personal?.name || 'Your Name'}</Text>
                    <Text style={[ptStyles.sectorLabel, { color }]}>{sectorLabel} · Part-Time</Text>
                    <View style={ptStyles.contactRow}>
                        {personal?.email && <Text>{personal.email}</Text>}
                        {personal?.phone && <Text>{personal.phone}</Text>}
                        {personal?.location && <Text>{personal.location}</Text>}
                    </View>
                </View>

                <View style={ptStyles.body}>
                    {/* Personal Statement */}
                    {objective?.trim() && (
                        <View style={[ptStyles.statementBox, { borderLeftColor: color }]}>
                            <Text style={[ptStyles.sectionLabel, { color, borderBottomColor: color }]}>Personal Statement</Text>
                            <Text style={ptStyles.statementText}>{objective}</Text>
                        </View>
                    )}

                    {/* Two-column layout */}
                    <View style={ptStyles.twoCol}>
                        {/* Left: Skills + Education */}
                        <View style={ptStyles.leftCol}>
                            {skills?.filter(s => s.trim()).length > 0 && (
                                <View style={{ marginBottom: 16 }}>
                                    <Text style={[ptStyles.sectionLabel, { color, borderBottomColor: color }]}>Key Skills</Text>
                                    {skills.filter(s => s.trim()).map((sk, i) => (
                                        <View key={i} style={[ptStyles.skillItem, { borderBottomColor: '#f1f5f9' }]}>
                                            <Text style={[ptStyles.skillDot, { color }]}>▸</Text>
                                            <Text style={ptStyles.skillText}>{sk}</Text>
                                        </View>
                                    ))}
                                </View>
                            )}
                            {education?.length > 0 && (
                                <View>
                                    <Text style={[ptStyles.sectionLabel, { color, borderBottomColor: color }]}>Education</Text>
                                    {education.map((edu, i) => (
                                        <View key={i} style={ptStyles.eduBlock}>
                                            <Text style={ptStyles.eduInst}>{edu.institution || '—'}</Text>
                                            {edu.degree && <Text style={[ptStyles.eduDeg, { color }]}>{edu.degree}</Text>}
                                            {edu.period && <Text style={ptStyles.eduPeriod}>{edu.period}</Text>}
                                        </View>
                                    ))}
                                </View>
                            )}
                        </View>

                        {/* Right: Experience */}
                        <View style={ptStyles.rightCol}>
                            {work_experience?.length > 0 && (
                                <View>
                                    <Text style={[ptStyles.sectionLabel, { color, borderBottomColor: color }]}>Work Experience</Text>
                                    {work_experience.map((job, i) => (
                                        <View key={i} style={ptStyles.jobBlock} wrap={false}>
                                            <View style={ptStyles.jobRow}>
                                                <Text style={ptStyles.jobRole}>{job.role || '—'}</Text>
                                                {job.period && <Text style={ptStyles.jobBadge}>{job.period}</Text>}
                                            </View>
                                            {job.company && <Text style={[ptStyles.jobCompany, { color }]}>{job.company}</Text>}
                                            {job.bullets?.filter(b => b.trim()).map((b, bi) => (
                                                <View key={bi} style={ptStyles.bullet}>
                                                    <Text style={ptStyles.bulletDot}>•</Text>
                                                    <Text style={ptStyles.bulletText}>{b}</Text>
                                                </View>
                                            ))}
                                        </View>
                                    ))}
                                </View>
                            )}
                        </View>
                    </View>

                    <Text style={ptStyles.footer}>References available upon request · Part-Time CV · Generated with GokulCV</Text>
                </View>
            </Page>
        </Document>
    );
};
